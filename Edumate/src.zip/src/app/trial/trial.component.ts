import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-trial',
  templateUrl: './trial.component.html',
  styleUrls: ['./trial.component.css','./css/bootstrap.min.css','./css/style.css','./font-awesome/css/font-awesome.min.css']
})
export class TrialComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
