export interface produ {
    itemId:number;
    itemName:string;
    itemImage:string;
}