import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css','./css/style.css','./css/bootstrap.min.css','./scss/style.scss']
})
export class HomeComponent implements OnInit {
  constructor(){}
  title = localStorage.getItem("regdNo");

  ngOnInit(): void {
  }

}
